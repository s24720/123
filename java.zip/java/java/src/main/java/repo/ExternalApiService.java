package repo;

@Service
public class ExternalApiService {

    @Value("${api.key}")
    private String apiKey;

    private RestTemplate restTemplate;

    public ExternalApiService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

    public String getDataFromApi() {
        String url = "https://api.example.com/data?api_key=" + apiKey;
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
        return response.getBody();
    }
}
