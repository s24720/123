@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public List<ProductDTO> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return products.stream().map(ProductDTO::new).collect(Collectors.toList());
    }

    @GetMapping("/products/{id}")
    public ProductDTO getProduct(@PathVariable("id") Long productId) {
        Product product = productService.getProduct(productId);
        return new ProductDTO(product.getId(), product.getName(), product.getPrice(), product.getDescription());
    }

    @PostMapping("/products")
    public void createProduct(@RequestBody ProductDTO productDTO) {
        productService.createProduct(new Product(productDTO.getName(), productDTO.getPrice(), productDTO.getDescription()));
    }

    @PutMapping("/products/{id}")
    public void updateProduct(@PathVariable("id") Long productId, @RequestBody ProductDTO updatedProductDTO) {
        productService.updateProduct(productId, new Product(updatedProductDTO.getName(), updatedProductDTO.getPrice(), updatedProductDTO.getDescription()));
    }

    @DeleteMapping("/products/{id}")
    public void deleteProduct(@PathVariable("id") Long productId) {
        productService.deleteProduct(productId);
    }



}


