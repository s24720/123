package com.example.service;

import com.example.contract.AddressDto;
import com.example.contract.PersonDto;
import com.example.model.Address;
import com.example.model.AddressRepository;
import com.example.model.Person;
import com.example.model.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

public class PersonService {
    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private AddressRepository addressRepository;

    public List<PersonDto> getAll() {
        List<Person> persons = personRepository.findAll();
        return persons.stream().map(p -> mapToDTO(p)).collect(Collectors.toList());
    }

    public void save(PersonDto personDto) {
        Person person = mapToEntity(personDto);
        personRepository.save(person);
    }

    public void update(PersonDto personDto) {
        Person person = mapToEntity(personDto);
        personRepository.save(person);
    }

    public void delete(int personId) {
        personRepository.deleteById(personId);
    }

    public void addAddress(int personId, AddressDto addressDTO) {
        Person person = personRepository.findById(personId).orElse(null);
        if (person != null) {
            Address address = mapToEntity(addressDTO);
            address.setPerson(person);
            addressRepository.save(address);
        }
    }

    public List<AddressDto> getAddresses(int personId) {
        Person person = personRepository.findById(personId).orElse(null);
        if (person != null) {
            return person.getAddresses().stream().map(a -> mapToDTO(a)).collect(Collectors.toList());
        }
        return AddressDto.emptyList();
    }

    private PersonDto mapToDTO(Person person) {
        PersonDto personDTO = new PersonDto();
        personDTO.setId(person.getId());
        personDTO.setFirstName(person.getFirstName());
        personDTO.setLastName(person.getLastName());
        return personDTO;
    }

    private Person mapToEntity(PersonDto personDTO) {
        Person person = new Person();
        person.setId(personDTO.getId());
        person.setFirstName(personDTO.getFirstName());
        person.setLastName(personDTO.getLastName());
        return person;
    }

    private AddressDto mapToDTO(Address address) {
        AddressDto addressDTO = new AddressDto();
        addressDTO.setId(address.getId());
        addressDTO.setCity(address.getCity());
        addressDTO.setPostalCode(address.getPostalCode());
        addressDTO.setStreet(address.getStreet());
        return addressDTO;
    }

    private Address mapToEntity(AddressDto addressDTO) {
        Address address = new Address();
        address.setId(addressDTO.getId());
        address.setCity(addressDTO.getCity());
        address.setPostalCode(addressDTO.getPostalCode());
        address.setStreet(addressDTO.getStreet());
        return address;
    }


}