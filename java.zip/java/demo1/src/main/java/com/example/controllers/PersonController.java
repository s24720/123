package com.example.controllers;


import com.example.contract.AddressDto;
import com.example.contract.PersonDto;
import com.example.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/person")
public class PersonController {

    @Autowired
    private PersonService personService;

    @GetMapping
    public ResponseEntity<List<PersonDto>> getAll() {
        List<PersonDto> persons = personService.getAll();
        return ResponseEntity.ok(persons);
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody PersonDto personDTO) {
        personService.save(personDTO);
        return ResponseEntity.ok().build();
    }


//    @GetMapping("/{id}")
//    public ResponseEntity<PersonDto> getById(@PathVariable int id) {
//        PersonDto person = personService.getAll(id);
//        if (person != null) {
//            return ResponseEntity.ok(person);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@PathVariable int id, @RequestBody PersonDto personDTO) {
        personDTO.setId(id);
        personService.update(personDTO);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        personService.delete(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}/addresses")
    public ResponseEntity<List<AddressDto>> getAddresses(@PathVariable int id) {
        List<AddressDto> addresses = personService.getAddresses(id);
        if (addresses != null) {
            return ResponseEntity.ok(addresses);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/addresses")
    public ResponseEntity<Void> addAddress(@PathVariable int id, @RequestBody AddressDto addressDTO) {
        personService.addAddress(id, addressDTO);
        return ResponseEntity.ok().build();
    }

}
